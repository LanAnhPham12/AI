package BaiTap2;

public class NQueenSolver {

}
