package BaiTap2;

import java.util.List;

public class Main {


	    public static void main(String[] args) {
	        int n = 4;
	        NQueenSolver solver = new NQueenSolver(n);
	        solver.solve();

	        List<Node> solutions = solver.getSolutions();
	        for (Node solution : solutions) {
	            System.out.println(solution.getState());
	        }
	    }

	}
