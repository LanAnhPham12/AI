package BaiTap2;

public class Node {

}
