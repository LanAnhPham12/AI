package bt3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class LocalSearch {

    private int n;
    private State currentState;

    public LocalSearch(int n) {
        this.n = n;
        this.currentState = new State(n);
    }

    public State solve() {
        while (true) {
            List<State> neighbours = currentState.generateNeighbours();
            State bestNeighbour = selectBestNeighbour(neighbours);
            if (bestNeighbour == null) {
                break;
            }
            currentState = bestNeighbour;
        }
        return currentState;
    }

    public State simulatedAnnealing(int maxSteps, double initialTemperature, double coolingRate) {
        for (int i = 0; i < maxSteps; i++) {
            List<State> neighbours = currentState.generateNeighbours();
            State bestNeighbour = selectBestNeighbour(neighbours);
            if (bestNeighbour != null) {
                currentState = bestNeighbour;
            } else {
                double temperature = initialTemperature * Math.pow(coolingRate, i);
                double probability = Math.exp((currentState.evaluate() - bestNeighbour.evaluate()) / temperature);
                if (Math.random() < probability) {
                    currentState = bestNeighbour;
                }
            }
        }
        return currentState;
    }

    public State tabuSearch(int maxSteps, int tabuListSize) {
        List<State> tabuList = new ArrayList<>();
        for (int i = 0; i < maxSteps; i++) {
            List<State> neighbours = currentState.generateNeighbours();
            List<State> nonTabuNeighbours = new ArrayList<>();
            for (State neighbour : neighbours) {
                if (!tabuList.contains(neighbour)) {
                    nonTabuNeighbours.add(neighbour);
                }
            }
            State bestNeighbour = selectBestNeighbour(nonTabuNeighbours);
            if (bestNeighbour != null) {
                currentState = bestNeighbour;
                tabuList.add(currentState);
                if (tabuList.size() > tabuListSize) {
                    tabuList.remove(0);
                }
            } else {
                // Thêm mã xử lý khi không tìm được neighbour nào tốt hơn
            }
        }
        return currentState;
    }

    private State selectBestNeighbour(List<State> neighbours) {
        State bestNeighbour = null;
        int bestCost = Integer.MAX_VALUE;
        for (State neighbour : neighbours) {
            int cost = neighbour.evaluate();
            if (cost < bestCost) {
                bestCost = cost;
                bestNeighbour = neighbour;
            }
        }
        return bestNeighbour;
    }

    // Lớp State được viết ở đây

    private class State {

        private int n;
        private List<Integer> positions;

        public State(int n) {
            this.n = n;
            this.positions = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                positions.add(i);
            }
            Collections.shuffle(positions);
        }

        public int evaluate() {
            int cost = 0;
            for (int i = 0; i < n; i++) {
                for (int j = i + 1; j < n; j++) {
                    if (positions.get(i) == positions.get(j) || Math.abs(i - j) == Math.abs(positions.get(i) - positions.get(j))) {
                        cost++;
                    }
                }
            }
            return cost;
        }

        public List<State> generateNeighbours() {
            List<State> neighbours = new ArrayList<>();
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    if (i != j) {
                        List<Integer> newPositions = new ArrayList<>(positions);
                        Collections.swap(newPositions, i, j);
                        neighbours.add(new State(n, newPositions));
                    }
                }
            }
            return neighbours;
        }

        public String toString() {
            return positions.toString();
        }
    }
}
