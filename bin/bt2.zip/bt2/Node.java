package bt2;

import java.util.ArrayList;
import java.util.List;

public class Node {

	private int n;
	private List<Integer> state;
	private List<Node> neighbours;

	public Node(int n) {
		this.n = n;
		this.state = new ArrayList<>();
		this.neighbours = new ArrayList<>();
	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	public List<Integer> getState() {
		return state;
	}

	public void setState(List<Integer> state) {
		this.state = state;
	}

	public List<Node> getNeighbours() {
		return neighbours;
	}

	public void setNeighbours(List<Node> neighbours) {
		this.neighbours = neighbours;
	}

	public void addNeighbours(Node neighbourNode) {
		this.neighbours.add(neighbourNode);
	}

	public boolean isValid(List<Integer> state) {
		if (state.size() == 1) {
			return true;
		}

		for (int i = 0; i < state.size() - 1; i++) {
			int currentQueenCol = state.get(i);
			int newQueenCol = state.get(state.size() - 1);
			if (currentQueenCol == newQueenCol) {
				return false;
			}
			int diff = Math.abs(currentQueenCol - newQueenCol);
			if (diff == state.size() - 1 - i) {
				return false;
			}
		}
		return true;
	}

	private List<Integer> place(int x) {
		List<Integer> newState = new ArrayList<>(state);
		newState.add(x);

		if (!isValid(newState)) {
			return null;
		}
		return newState;
	}

}
