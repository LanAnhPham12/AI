package bt2;

import java.util.ArrayList;
import java.util.List;

public class NQueenSolver {

    private int n;
    private List<Node> solutions;

    public NQueenSolver(int n) {
        this.n = n;
        this.solutions = new ArrayList<>();
    }

    public void solve() {
        Node rootNode = new Node(n);
        for (int i = 0; i < n; i++) {
            List<Integer> state = new ArrayList<>();
            state.add(i);
            Node node = new Node(n);
            node.setState(state);
            rootNode.addNeighbours(node);
        }

        solve(rootNode);
    }

    private void solve(Node node) {
        if (node.getState().size() == n) {
            solutions.add(node);
            return;
        }

        for (Node neighbourNode : node.getNeighbours()) {
            solve(neighbourNode);
        }
    }

    public List<Node> getSolutions() {
        return solutions;
    }

}

