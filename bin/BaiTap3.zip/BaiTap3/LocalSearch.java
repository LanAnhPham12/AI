package BaiTap3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class LocalSearch {

    private int n;
    private List<Integer> state;

    public LocalSearch(int n) {
        this.n = n;
        this.state = new ArrayList<Integer>();
        for (int i = 0; i < n; i++) {
            Random r = new Random();
            this.state.add(r.nextInt(n));
        }
    }

    public int evaluateState() {
        int cost = 0;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (state.get(i) == state.get(j) || abs(i - j) == abs(state.get(i) - state.get(j))) {
                    cost++;
                }
            }
        }
        return cost;
    }

    public List<List<Integer>> generateNeighbours() {
        List<List<Integer>> neighbours = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i != j) {
                    List<Integer> new_state = new ArrayList<>(state);
                    new_state.set(i, state.get(j));
                    new_state.set(j, state.get(i));
                    neighbours.add(new_state);
                }
            }
        }
        return neighbours;
    }

    public List<Integer> solve() {
        while (true) {
            List<List<Integer>> neighbours = generateNeighbours();
            List<Integer> bestNeighbour = null;
            int bestCost = Integer.MAX_VALUE;
            for (List<Integer> neighbour : neighbours) {
                int cost = evaluateState();
                if (cost < bestCost) {
                    bestCost = cost;
                    bestNeighbour = neighbour;
                }
            }
            if (bestNeighbour == null) {
                break;
            }
            state = bestNeighbour;
        }
        return state;
    }

    public static void main(String[] args) {
        int n = 4;
        LocalSearch localSearch = new LocalSearch(n);
        List<Integer> solution = localSearch.solve();
        System.out.println("Giải pháp cho bài toán N hậu với N = " + n + ": " + solution);
    }

    private int abs(int x) {
        return x < 0 ? -x : x;
    }

   

    public List<Integer> simulatedAnnealing(int maxSteps, double initialTemperature, double coolingRate) {
        List<Integer> currentState = state;
        int currentCost = evaluateState();
        for (int i = 0; i < maxSteps; i++) {
            List<List<Integer>> neighbours = generateNeighbours();
            List<Integer> bestNeighbour = null;
            int bestCost = Integer.MAX_VALUE;
            for (List<Integer> neighbour : neighbours) {
                int cost = evaluateState();
                if (cost < bestCost) {
                    bestCost = cost;
                    bestNeighbour = neighbour;
                }
            }
            if (bestNeighbour != null) {
                currentState = bestNeighbour;
                currentCost = bestCost;
            } else {
                double temperature = initialTemperature * Math.pow(coolingRate, i);
                double probability = Math.exp((currentCost - bestCost) / temperature);
                if (Math.random() < probability) {
                    currentState = bestNeighbour;
                    currentCost = bestCost;
                }
            }
        }
        return currentState;
    }

    public List<Integer> tabuSearch(int maxSteps, int tabuListSize) {
        List<Integer> currentState = state;
        int currentCost = evaluateState();
        List<List<Integer>> tabuList = new ArrayList<>();
        for (int i = 0; i < maxSteps; i++) {
            List<List<Integer>> neighbours = generateNeighbours();
            List<Integer> bestNeighbour = null;
            int bestCost = Integer.MAX_VALUE;
            for (List<Integer> neighbour : neighbours) {
                if (!tabuList.contains(neighbour)) {
                    int cost = evaluateState();
                    if (cost < bestCost) {
                        bestCost = cost;
                        bestNeighbour = neighbour;
                    }
                }
            }
            if (bestNeighbour != null) {
                currentState = bestNeighbour;
                currentCost = bestCost;
                tabuList.add(currentState);
                if (tabuList.size() > tabuListSize) {
                    tabuList.remove(0);
                }
            } else {
                           }
        }
        return currentState;
    }
}